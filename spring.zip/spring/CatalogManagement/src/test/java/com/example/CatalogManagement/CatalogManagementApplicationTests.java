package com.example.CatalogManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatalogManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
